package com.test;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


//@WebServlet("/test/Sport")
public class SportServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
 
   

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}
	
	protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//post방식에서의 한글처리
		request.setCharacterEncoding("utf-8");
		// 폼에 name 속성에 값을 얻어옴 
		String[] sports = request.getParameterValues("sports");
		String gender = request.getParameter("gender");
		
		//응답
		response.setContentType("text/html;charset=utf-8");
		
		PrintWriter out = response.getWriter();
		
		out.print("<html><body>");
		for(String sport : sports) {
			out.println("좋아하는 운동 :"+sport +"<br>");
		}
		out.println("성별:"+gender+"<br>");
		out.println("</body></html>");
		
		
	}

}
