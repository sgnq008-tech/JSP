package com.jdbc;
import java.util.Vector;
import java.sql.*;
import javax.sql.*;
import javax.naming.*;
public class TempMemberDAO {
/*	private final String JDBC_DRIVER=
	"oracle.jdbc.driver.OracleDriver";
	private final String JDBC_URL=
	"jdbc:oracle:thin:@localhost:1521:orcl";
	private final String USER="scott";
	private final String PASS="tiger";
*/	
	DataSource ds;
	public TempMemberDAO() {
		try {
			Context init = new InitialContext();
	    	 
	    	ds = (DataSource)init.lookup("java:comp/env/jdbc/myOracle");
			//Class.forName(JDBC_DRIVER);
		}catch(Exception e) {
			System.out.println("Error:JDBC 드라이버 로딩 실패!!!");
		}
	}
	
	public Vector<TempMemberVO> getMemberList(){
		Connection con = null;
		Statement stmt = null;
		ResultSet rs = null;
		Vector<TempMemberVO> vecList =
				new Vector<TempMemberVO>();
		try {
			//con = DriverManager.getConnection(JDBC_URL,USER,PASS);
			con = ds.getConnection();
			String sql = "select *from tempmember";
			stmt = con.createStatement();
			rs= stmt.executeQuery(sql);
			while(rs.next()) {
				TempMemberVO vo = new TempMemberVO();
				vo.setId(rs.getString("id"));
				vo.setPasswd(rs.getString("passwd"));
				vo.setName(rs.getString("name"));
				vo.setMem_num1(rs.getString("mem_num1"));
				vo.setMem_num2(rs.getString("mem_num2"));
				vo.setE_mail(rs.getString("e_mail"));
				vo.setPhone(rs.getString("phone"));
				vo.setZipcode(rs.getString("zipcode"));
				vo.setAddress(rs.getString("address"));
				vo.setJob(rs.getString("job"));
				vecList.add(vo);
				
				
			}
			
			
			
		}catch(Exception ex) {
			System.out.println("Exception"+ex);
		}finally {
			if(rs != null) try {rs.close();}catch(SQLException e) {}
			if(stmt != null) try {stmt.close();}catch(SQLException e) {}
			if(con != null) try {con.close();}catch(SQLException e) {}
			
			
		}
		
		return vecList;
	}
}
