package com.login;

import java.io.*;
import javax.servlet.*;
import javax.servlet.annotation.*;
import javax.servlet.http.*;


@WebServlet("/LoginChectk")
public class LoginChectk extends HttpServlet {
	private static final long serialVersionUID = 1L;


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {		
		processRequest(request, response);
	}
	protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			request.setCharacterEncoding("utf-8");
			String id = request.getParameter("id");
			String pwd = request.getParameter("pwd");
			
			String dbID = "admin";
			String dbPWD = "1234";
			
			// 데이터베이스에 저장된 id, pwd 와 로그인폼에서 
			// 가져온 정보를 비교한다.
			if(dbID.equals(id)&& dbPWD.equals(pwd)) {
				HttpSession session = request.getSession();
				session.setAttribute("user", id);
			}
			response.sendRedirect("Login");
	}

}
