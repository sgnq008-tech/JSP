package com.sample;

import java.io.*;
import javax.servlet.*;
import javax.servlet.annotation.*;
import javax.servlet.http.*;

/*
 *	페이지 이동 방법 
 * 		-메소드를 호출을 통해서 페이지를 이동할 수있는 방법은 두가지가 있다. 
 * 		-forward, redirect 방법으로 이동 
 * 
 * 		구분					forward				redirect
 * 		url						url이 바뀌지 않는다. url이 바뀐다.
 * 		요청객체와 응답객체		유지된다.			유지되지 않는다.
 * 		속도					빠르다.				느리다.
 * 		소속객체				request				response
 * 
 */

//@WebServlet("/Source")
public class Source extends HttpServlet {
	private static final long serialVersionUID = 1L;


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		processRequest(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		processRequest(request, response);
	}
	
	protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		System.out.println("Source Start ......");
		//페이지 이동
		// 1. forward 방식으로 이동
		//RequestDispatcher view = request.getRequestDispatcher("Destination");
		//view.forward(request, response);
		//2. redirect 방식으로 이동
		response.sendRedirect("Destination");
		
	}

}
