<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<!-- 속성은 PageContext, HttpServletRequest, HttpSession,
ServletContext 객체중 하나에 설정해 놓은 객체를 의미함
-속성은 객체 Map 인스턴스와 마찬가지로 이름/값의 형태의 쌍으로
저장되어있다.
-각각의 객체에 저장된 속성들은 서로 다른 생존범위(scope)를 가진다.
pageContext :
접근범위 : 해당 JSP 페이지 내에서만 허용
생존범위 : WAS가 shutdown 되기 전까지 유효하다.
사용범위 : 전체 어플리케이션에서 공유하는 자원에서 사용한다.
HttpServlet Request
접근범위 : 어플리케이션에서 request에 접근 가능한 것들
생존범위 : 사용자가 요청 객체가 유지되는 동안에는 유효하다.
사용범위 : MVC 패턴에서 Model 정보를 view에 전달할때 사용함 
HttpSession
접근범위 :	특정 세션에 접근할 수 있는 Servlet이나 JSP
생존범위 :	HttpSession 객체 생존까지만 유효하다
사용범위 :	전체 어플리케이션에서 공유하는 자원에서 사용한다.
ServletContext
접근범위:	어플리케이션 내의 모든 것 들을 -->
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
<%
pageContext.setAttribute("pageAttribute","홍길동");
pageContext.setAttribute("pageAttribute","홍길동");

%>

</body>
</html>