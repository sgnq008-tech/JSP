<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<% request.setCharacterEncoding("utf-8"); %>
<jsp:useBean id="dao" class ="com.memberone.studentDAO" />
<jsp:useBean id="vo" class="com.memberone.studentVO" />

<jsp:setProperty property="*" name="vo"/>
<%
	boolean flag = dao.memberInsert(vo);
%>
	

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8" http-equiv="refresh" content="3;url='login.jsp'">
<title>회원가입 확인</title>
<link href = "style.css" rel = "stylesheet" type= "text/css">
</head>
<body bgcolor="#ffffcc">
<div align="center">
<%
	if(flag){
		out.println("<b>회원 가입을 진심으로 축하드립니다.</b>");
		//out.println("<a href=login.jsp>로그인</a>");
	}else{
		out.println("<b>다시 입력해 주세요.</b><b>");
		out.println("<a href=regForm.jsp>다시가입</a>");
	}
%>
</div>
</body>
</html>