<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
    <%@ page import= "java.sql.*" %>
    <%@ page import= "javax.sql.*" %>
    <%@ page import= "javax.naming.*" %>
    <%
    Connection con = null; 
    
    try {
    	Context init = new InitialContext();
    	DataSource 
    	ds = (DataSource)init.lookup("java:comp/env/jdbc/myOracle");
    	con = ds.getConnection();
    	out.println("데이터 베이스연결 성공!!");
    }catch(SQLException s){
    	s.printStackTrace();
    }
    
    
    %>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>

</body>
</html>