<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%--
	자바빈즈 : 자바 클래스 중에 자바빈즈 규약에 맞게 작성한 클래스임
				멤버변수와 setter/getter 메소드로 이루어져 있다.
				값을 저장하는 Value Object(VO) 로 활용한다.
	<jsp:useBean> 액션 태그 
	- 객체의 이름과 사용범위, 빈의 저장 위치 등을 통해서 객체 생성된다.
	 JSP의 자바코드에서는 action의 id 특성에 지정된 값을 통해서 
	 객체를 참조한다.
	 - 형식: <jsp: useBean id="빈 이름" scope = "범위" class="빈의 저장위치"
	 - id : 객체명 (인스턴스를 식별하는 이름)
	 - scope : 객체를 참조하는 유효 범위
	 - class : 완전한 형태의 클래스이름 
	 
	 <jsp :setProperty> : 빈의 속성에 값을 설정하는 태그
	 형식 : <jsp: setProperty name ="" property="프로퍼티명"value="저장할 값">
	 name : <jsp:useBean> 태그에 정의 빈 이름
	 property : 값을 설정하고자하는 빈 속성의 이름, '*'설정시
	 			servletReaquest안의 모든 인자들 중 빈속성과 데이터 형이
	 			일치하는 것을 찾아 각각의 속성들을 각각의 인자값으로 설정함
	 value : 빈속성에 설정된 값
	<jsp: getProperty>: 빈 속성에 값을 얻어오는 태그
	형식<jsp:getProperty name ="빈 이름"property = "프로퍼티명">
	name : 속성을 얻고자하는 빈의 이름
	property: 얻고자 하는 속성의 이름
 --%>
 
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>자바 빈즈</title>
</head>
<body>
<h1>자바빈즈</h1>
<hr color = "red"><br>
<form action = "simpleBean.jsp">
메시지 : <input type = "text" name = "message">
		 <input type = "submit" value = "전송">
</form>
</body>
</html>