<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@ page isErrorPage="true" %>
<% response.setStatus(HttpServletResponse.SC_OK); %>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>예외 발생</title>
</head>
<body>
요청 처리 과정에서 에외가 발생하였습니다.<br>
고객님의 불편함을 해소하기 하기불철주야 노력하겠습니다.<br>
빠른 시간내에 문제를 해결하겠습니다.
<br><br>
에러타입: <%= exception.getClass().getName() %>
에러메시지: <b><%=exception.getMessage() %></b>
</body>
</html>