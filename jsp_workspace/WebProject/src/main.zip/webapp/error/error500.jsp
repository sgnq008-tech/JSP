<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>

<%@ page import="javax.servlet.http.HttpServletResponse" %>

<%response.setStatus(HttpServletResponse.SC_OK);%>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>500 에러 발생</title>
</head>
<body>

<b>서비스 처리 과정에서 문제가 발생했습니다.</b><br>
<b>빠른 시간 안에 문제를 해결하도록 하겠습니다.</b>

</body>
</html>